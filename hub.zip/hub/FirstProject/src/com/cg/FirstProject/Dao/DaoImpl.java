package com.cg.FirstProject.Dao;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.FirstProject.Dto.BeanClass;

public class DaoImpl implements DaoInterface {
	Connection con = null;
	Statement st = null;
	ResultSet rs = null;

	@Override
	public BeanClass verifypassword(String username, String password) {
		// TODO Auto-generated method stub
		BeanClass bean = new BeanClass();
		
		try {
			Class.forName("com.mysql.jdbc.Driver");

			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "Sadek@123");
			st = con.createStatement();
			String q = "SELECT * FROM student_details where student_userid='" + username + "'and student_password='"
					+ password + "'";
			
			rs = st.executeQuery(q);
			System.out.println(rs);
			
			while (rs.next()) {
				bean.setStudent_id(rs.getInt(1));
				bean.setStudent_name(rs.getString(2));
				bean.setStudent_class(rs.getString(3));
				bean.setStudent_userid(rs.getString(4));
				bean.setStudent_password(rs.getString(5));
			
						
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(" sql exception please check or login failed");

		}
		return bean;
	}

	@Override
	public BeanClass registeruser(BeanClass bean) {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.jdbc.Driver");

			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "Sadek@123");

			PreparedStatement ps = con.prepareStatement("insert into student_details values(?,?,?,?,?)");
			ps.setInt(1, bean.getStudent_id());
			ps.setString(2, bean.getStudent_name());
			ps.setString(3, bean.getStudent_class());
			ps.setString(4, bean.getStudent_userid());
			ps.setString(5, bean.getStudent_password());
			int x = ps.executeUpdate();

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(" sql exception please check");

		}
		return bean;
	}
	@Override
	public List<BeanClass> getall() {
		// TODO Auto-generated method stub
	List<BeanClass> beanlist= new ArrayList();
		try {
			Class.forName("com.mysql.jdbc.Driver");

			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "Sadek@123");
			st = con.createStatement();
			String query="select * from student_details";
			
			rs = st.executeQuery(query);
			while(rs.next()){
				BeanClass bean=new BeanClass();
				 bean.setStudent_id(rs.getInt(1));
				 bean.setStudent_name(rs.getString(2));
				 bean.setStudent_class(rs.getString(3));
				 bean.setStudent_userid(rs.getString(4));
				 bean.setStudent_password(rs.getString(5));
				 beanlist.add(bean);
				 
				
				
			}
			System.out.println(beanlist);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(" sql exception please check");

		}
		return beanlist;
	}
	@Override
	public List<BeanClass> search(String searchby, String searchword) {
		List<BeanClass> beanlist= new ArrayList();
		String query = "";
		System.out.println("searchby"+searchby+"searcchword"+searchword);
		try {
			Class.forName("com.mysql.jdbc.Driver");

			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "Sadek@123");
			st = con.createStatement();
			if(searchby .equals("id")){
				int x=Integer.parseInt(searchword);
				 query="select * from student_details where student_id="+x;
			}
			else if(searchby.equals("class")){
				 query="select * from student_details where student_class='"+searchword+"'";
			}
			else {
				 query="select * from student_details where student_name='"+searchword+"'";
			}
			System.out.println(query);
			rs = st.executeQuery(query);
			
			while(rs.next()){
				BeanClass bean=new BeanClass();
				 bean.setStudent_id(rs.getInt(1));
				 bean.setStudent_name(rs.getString(2));
				 bean.setStudent_class(rs.getString(3));
				 bean.setStudent_userid(rs.getString(4));
				 bean.setStudent_password(rs.getString(5));
				 beanlist.add(bean);
				 
				
				
			}
			System.out.println(beanlist);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(" sql exception please check");
			e.printStackTrace();
		}
		
		
		
		
		return beanlist;
	}
}
