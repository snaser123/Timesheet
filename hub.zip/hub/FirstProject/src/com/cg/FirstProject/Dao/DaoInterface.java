package com.cg.FirstProject.Dao;

import java.util.List;

import com.cg.FirstProject.Dto.BeanClass;

public interface DaoInterface {
	public BeanClass verifypassword(String username,String password);

	public BeanClass registeruser(BeanClass bean);

	public List<BeanClass> getall();

	List<BeanClass> search(String searchby, String searchword);
}
