package com.cg.FirstProject.Dto;

public class BeanClass {
	private String student_name;
	private int student_id;
	private String student_class;
	private String student_userid;
	private String student_password;
	
	public String getStudent_name() {
		return student_name;
	}
	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}
	public int getStudent_id() {
		return student_id;
	}
	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}
	public String getStudent_class() {
		return student_class;
	}
	public void setStudent_class(String student_class) {
		this.student_class = student_class;
	}
	public String getStudent_userid() {
		return student_userid;
	}
	public void setStudent_userid(String student_userid) {
		this.student_userid = student_userid;
	}
	public String getStudent_password() {
		return student_password;
	}
	public void setStudent_password(String student_password) {
		this.student_password = student_password;
	}
	
	@Override
	public String toString() {
		return "BeanClass [student_name=" + student_name + ", student_id=" + student_id + ", student_class="
				+ student_class + ", student_userid=" + student_userid + ", student_password=" + student_password + "]";
	}

}
