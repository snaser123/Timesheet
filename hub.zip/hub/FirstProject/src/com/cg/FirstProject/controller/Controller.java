package com.cg.FirstProject.controller;

import org.springframework.web.servlet.ModelAndView;

import com.cg.FirstProject.Dto.BeanClass;
import com.cg.FirstProject.Service.ServiceImpl;

import java.util.List;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@org.springframework.stereotype.Controller
public class Controller {

	 @RequestMapping("/login.html")
	   public ModelAndView helloWord(@RequestParam("username") String username
			   ,@RequestParam String password){
		      
		  		ServiceImpl service=new ServiceImpl();
		  		BeanClass bean=service.verifypassword(username, password); 
		  		System.out.println(bean);
		  		ModelAndView mv=new ModelAndView();
		  		mv.addObject(bean);
		  		if(bean.getStudent_name()==null){
		  			return new ModelAndView("loginfailed");
		  		}
		  		else{
		      return new ModelAndView("loginsuccess","bean",bean);}
	   }
	
	 @RequestMapping("/register-form.html")
	   public ModelAndView register(){	  		
		      return new ModelAndView("register","bean",new BeanClass());
	   }
	 @RequestMapping("/register.html")
	   public ModelAndView register2(@ModelAttribute("bean") BeanClass bean ){
		      BeanClass bean1=new BeanClass();
		 ServiceImpl service=new ServiceImpl();
		bean1= service.registeruser(bean); 
	  		System.out.println(bean1);
		  		
		      return new ModelAndView("loginsuccess","bean",bean1); 
	   }
	 @RequestMapping("/list.html")
	   public ModelAndView list( ){
		     
		 ServiceImpl service=new ServiceImpl();
		 List<BeanClass> beanlist= service.getall();
		
		      return new ModelAndView("list","beanlist",beanlist); 
	   }
	 @RequestMapping("/search.html")
	   public ModelAndView search(@RequestParam("searchby") String searchby,@RequestParam("searchword") String searchword){
		
		 System.out.println("search by"+searchby);
		 System.out.println("search word"+searchword);
		 System.out.println(searchby.equals("class"));
		 String x=searchby;
		 System.out.println(x=="class");
		 ServiceImpl service=new ServiceImpl();
		 List<BeanClass> beanlist= service.search(searchby,searchword);
		
		      return new ModelAndView("list","beanlist",beanlist); 
	   }
	
	 
}
