package com.cg.FirstProject.Service;

import java.util.List;

import com.cg.FirstProject.Dao.DaoImpl;
import com.cg.FirstProject.Dto.BeanClass;

public class ServiceImpl implements ServiceInterface{
	
	@Override
	public BeanClass verifypassword(String username,String password){
		
		DaoImpl dao=new DaoImpl();
		
		return dao.verifypassword(username, password);
		
	}
	@Override
	public BeanClass registeruser(BeanClass bean) {
		// TODO Auto-generated method stub
			DaoImpl dao=new DaoImpl();
		
		return dao.registeruser(bean);
	}
	@Override
	public List<BeanClass> getall() {
		// TODO Auto-generated method stub
		DaoImpl dao=new DaoImpl();
		
		return dao.getall();
		
	}
	@Override
	public List<BeanClass> search(String searchby, String searchword) {
		DaoImpl dao=new DaoImpl();
		return dao.search(searchby,searchword);
		// TODO Auto-generated method stub
		
	}
}
