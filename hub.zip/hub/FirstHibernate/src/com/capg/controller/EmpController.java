package com.capg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capg.dto.EmpBeans;
import com.capg.service.ServiceInt;

@Controller
public class EmpController {
	
	@Autowired
	private ServiceInt serviceInt;
	
	public ServiceInt getPerService() {
		return serviceInt;
	}
	public void setPerService(ServiceInt ServiceInt) {
		this.serviceInt = ServiceInt;
	} 
	
	@RequestMapping(value="/add.html")
	public ModelAndView add(){
		
		return new ModelAndView("addemp","bean",new EmpBeans());
	}

	@RequestMapping(value="/added.html")
	public ModelAndView added(@ModelAttribute("bean") @Valid EmpBeans bean,
			BindingResult result){
		System.out.println(result.hasErrors());
		if(result.hasErrors()){
			System.out.println(" in errors");
			return new ModelAndView("addemp");
		}
	EmpBeans bean1=serviceInt.addemp(bean);
		
		return new ModelAndView("success","bean",bean1);
		
	}
	@RequestMapping(value="/list.html")
	public ModelAndView listofall(){
		
		List<EmpBeans> list= serviceInt.listall();
		 for(EmpBeans model : list) {
	            System.out.println(model.getEmp_name());
	        }
		return new ModelAndView("successlist","list",list);
		
	}
}
