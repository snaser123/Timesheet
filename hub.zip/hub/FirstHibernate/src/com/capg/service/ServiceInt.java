package com.capg.service;

import java.util.List;

import com.capg.dto.EmpBeans;

public interface ServiceInt {
	
	public EmpBeans addemp(EmpBeans bean);

	public List<EmpBeans> listall();

}
