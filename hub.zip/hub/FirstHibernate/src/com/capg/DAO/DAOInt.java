package com.capg.DAO;


import java.util.List;

import com.capg.dto.EmpBeans;

public interface DAOInt {
	
	public EmpBeans addemp(EmpBeans bean);

	public List<EmpBeans> listall();
	
}
