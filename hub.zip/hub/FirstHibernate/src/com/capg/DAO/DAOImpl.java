package com.capg.DAO;


import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capg.dto.EmpBeans;

@Repository

public class DAOImpl implements DAOInt {

	@Autowired
	public SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public EmpBeans addemp(EmpBeans bean) {
		// TODO Auto-generated method stub

		Session session = sessionFactory.openSession();
		// System.out.println(session);
		session.beginTransaction();
		session.save(bean);
		session.getTransaction().commit();
		session.close();

		return bean;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<EmpBeans> listall() {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
        List<EmpBeans> list = session.createQuery("from EmpBeans").list(); 
		
        session.close(); 
		for(EmpBeans bean:list){
			System.out.println(bean+"in beans");
			
		}       
				 return list;
	}

}
