package com.capg.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capg.DAO.DAOInt;
import com.capg.dto.EmpBeans;


@Service

public class ServiceImpl implements ServiceInt {

	@Autowired
	private DAOInt DAOInt;

	public DAOInt getPerDAOInt() {
		return DAOInt;
	}

	public void setPerDAOInt(DAOInt perDAOInt) {
		this.DAOInt = perDAOInt;
	}

	@Override
	public EmpBeans addemp(EmpBeans bean) {
		// TODO Auto-generated method stub
		return DAOInt.addemp(bean);
	}

	@Override
	public List<EmpBeans> listall() {
		// TODO Auto-generated method stub
		return DAOInt.listall();
	}

	@Override
	public EmpBeans delete(int sId) {
		// TODO Auto-generated method stub
		return DAOInt.delete(sId);
	}

	@Override
	public EmpBeans search(int sId) {
		// TODO Auto-generated method stub
		return DAOInt.search(sId);
	}

	

}
