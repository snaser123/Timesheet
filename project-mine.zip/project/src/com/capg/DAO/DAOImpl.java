package com.capg.DAO;


import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capg.dto.EmpBeans;

@Repository

public class DAOImpl implements DAOInt {

	@Autowired
	public SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public EmpBeans addemp(EmpBeans bean) {
		// TODO Auto-generated method stub

		Session session = sessionFactory.openSession();
		// System.out.println(session);
		session.beginTransaction();
		session.save(bean);
		session.getTransaction().commit();
		session.close();

		return bean;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<EmpBeans> listall() {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
        List<EmpBeans> list = session.createQuery("from EmpBeans").list(); 
		
        session.close(); 
		 return list;
	}
	@Override
	public EmpBeans delete(int sId) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
        session.beginTransaction(); 
       EmpBeans stud = (EmpBeans) session.get(EmpBeans.class, sId); 
        
        	session.delete(stud);
        	session.getTransaction().commit(); 
        	session.close();
        	return stud;
        	}



	@Override
	public EmpBeans search(int sId) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
        session.beginTransaction(); 
        EmpBeans stud = (EmpBeans) session.get(EmpBeans.class, sId); 
        	session.getTransaction().commit(); 
        	session.close();
        	System.out.println("in contrroller"+stud);
        	return stud;
        
	}

}
