package com.capg.controller;

import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capg.dto.EmpBeans;
import com.capg.service.ServiceInt;

@Controller
public class EmpController {
	
	@Autowired
	private ServiceInt serviceInt;
	
	public ServiceInt getPerService() {
		return serviceInt;
	}
	public void setPerService(ServiceInt ServiceInt) {
		this.serviceInt = ServiceInt;
	} 
	
	@RequestMapping(value="/add.html")
	public ModelAndView add(){
		
		return new ModelAndView("addemp","bean",new EmpBeans());
	}

	@RequestMapping(value="/added.html")
	public ModelAndView added(@ModelAttribute("bean") @Valid EmpBeans bean,
			BindingResult result,HttpServletRequest request, HttpServletResponse response){
		
		if(result.hasErrors()){
			
			return new ModelAndView("addemp","bean",bean);
		}
	EmpBeans beanadd=serviceInt.addemp(bean);
	 Cookie ck[] = request.getCookies();
     System.out.println(ck);
		return new ModelAndView("success","bean",beanadd);
		
	}
	@RequestMapping(value="/list.html")
	public ModelAndView listofall(){
		
		List<EmpBeans> list= serviceInt.listall();
				
		return new ModelAndView("successlist","list",list);
		
	}
	@RequestMapping(value="/search.html")
	public ModelAndView search(@RequestParam("empid") String empid){
		System.out.println("in controller");
	int empid1=Integer.parseInt(empid);
	System.out.println(empid);
		EmpBeans bean=serviceInt.search(empid1);
		System.out.println(bean);
		return new ModelAndView("success","bean",bean);
		
	}
	@RequestMapping(value="/delete.html")
	public String delete(@RequestParam("empid") String empid){
	int empid1=Integer.parseInt(empid);
	System.out.println(empid);
		serviceInt.delete(empid1);

		return  "redirect:list.html";
		
	}
	@RequestMapping(value="/cookie.html")
	public String cookies(@RequestParam("userid") String userid,@RequestParam("password") String password,HttpServletRequest request, HttpServletResponse response,HttpSession session){
		
		 Cookie newCookie = new Cookie("userid", userid);
		 Cookie newCookie1 = new Cookie("password", password);
	        response.addCookie(newCookie);
	        response.addCookie(newCookie1);
		System.out.println("in controller cookie");
		session.setAttribute("code","code");
		session.setMaxInactiveInterval(60);
		System.out.println(session);
		return  "redirect:list.html";
		
	}
}
