package com.capg.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.springframework.validation.annotation.Validated;
@Validated
@Entity
@Table(name = "employee_details")
public class EmpBeans {

	@Id
	@Column(name = "emp_id")
	@Range(min = 0, max = 1500000)
	private int emp_id;
	
	@Column(name = "emp_name")
	@NotEmpty(message="not empty")
	private String emp_name;
	
	@Column(name = "emp_sal")
	@NotNull(message="should not be empty")
	@Range(min = 0, max = 1500000)	
	private int emp_sal;

	public int getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public int getEmp_sal() {
		return emp_sal;
	}

	public void setEmp_sal(int emp_sal) {
		this.emp_sal = emp_sal;
	}

	@Override
	public String toString() {
		return "Beans [emp_id=" + emp_id + ", emp_name=" + emp_name + ", emp_sal=" + emp_sal + "]";
	}
	
	
	
	
}
